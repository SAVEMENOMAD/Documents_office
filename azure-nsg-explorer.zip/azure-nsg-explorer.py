from sre_constants import AT_END_STRING
import requests
import json
from pprint import pprint

def get_token():
    url = 'http://localhost:50342/oauth2/token'
    MANAGEMENTAPIHEADER = {
        'Metadata': 'true',
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    data = 'resource=https://management.azure.com/'
    response = requests.post(url, headers=MANAGEMENTAPIHEADER, data=data)
    response = json.loads(response.text)
    return response["access_token"]

def get_active_subscriptions(bearer_token):
    subscriptions = {}
    url = 'https://management.azure.com/subscriptions?api-version=2020-01-01'
    MANAGEMENTAPIHEADER = {
        "Authorization": "Bearer "
        + bearer_token,
        "host": "management.azure.com",
        "Content-Type": "application/json",
    }
    response = requests.get(url, headers=MANAGEMENTAPIHEADER).json()
    if "error" in response.keys():
            print(f"- Failed to get subscriptions due to {response.get('error').get('message')}")
            exit()
    else:
        for each in response.get("value"):
            if each.get("state") == "Enabled":
                subscriptions[each["subscriptionId"]] = each["displayName"]
            else:
                pass

    return subscriptions

def get_subscription_nsg(bearer_token, subscription):
    nsgs = {}
    url = f"https://management.azure.com/subscriptions/{subscription}/providers/Microsoft.Network/networkSecurityGroups?api-version=2021-08-01"
    MANAGEMENTAPIHEADER = {
        "Authorization": "Bearer "
        + bearer_token,
        "host": "management.azure.com",
        "Content-Type": "application/json",
    }
    response = requests.get(url, headers=MANAGEMENTAPIHEADER).json()
    if "error" in response.keys():
        print(f"- Failed to get NSGs due to {response.get('error').get('message')}")
        exit()
    else:
        for each in response.get("value"):
            nsgs[each["id"]] = each["name"]
    return nsgs

def get_security_rules(subscription,resourceGroupName, networkSecurityGroupName, bearer_token):
    url = f"https://management.azure.com/subscriptions/{subscription}/resourceGroups/{resourceGroupName}/providers/Microsoft.Network/networkSecurityGroups/{networkSecurityGroupName}/securityRules?api-version=2021-08-01"
    MANAGEMENTAPIHEADER = {
        "Authorization": "Bearer "
        + bearer_token,
        "host": "management.azure.com",
        "Content-Type": "application/json",
    }
    response = requests.get(url, headers=MANAGEMENTAPIHEADER).json()
    #print(response)
    if "error" in response.keys():
        print(f"- Failed to get NSGs due to {response.get('error').get('message')}")
        exit()
    else:
        return response["value"]

def addressprefixvalidator(AddressPrefix):
    for each in AddressPrefix:
        if "/0" in each or each.lower() in ["*", "any", "azurecloud", "internet"]:
            return True
        else:
            return False


try:
    compliant_rules_inbound = []
    compliant_rules_outbound = []
    non_compliant_rules_inbound = []
    non_compliant_rules_outbound = []
    print("You have access to below Azure subscriptions.\n")
    count = 1
    bearer_token = get_token()
    subscriptions = get_active_subscriptions(bearer_token)
    if not bool(subscriptions):
        print("No active subscription found. Please try again.")
        exit()
    else:
        for each in subscriptions.keys():
            print(f"{count}) {each} [{subscriptions[each]}]")
            count += 1
        flag = input("\nPlease select the index of your subscription having non-compliant NSG(1,2,..):")
        while (int(flag) not in range(1,count)):
            flag = input("Wrong input! Please try again:")
            
        subscription = list(subscriptions)[int(flag) - 1]
        nsgs = get_subscription_nsg(bearer_token, subscription)
        if not bool(nsgs):
            print("No NSG found under the selected subscription. Please try again.")
            exit()
        else:
            key_list = list(nsgs.keys())
            val_list = list(nsgs.values())
            count = 1
            print(f"\nBelow are the NSGs under the selected subscription.")
            for each in val_list:
                print(f"{count}) {each}")
                count += 1
            flag = input("\nPlease select the index of non-compliant NSG(1,2,..):")
            while (int(flag) not in range(1,count)):
                flag = input("Wrong input! Please try again:")
            
            rg = key_list[int(flag) - 1].split('/')[4]
            nsg = val_list[int(flag) - 1]
            if rg is None or nsg is None:
                print("Resource Group or Network Security Group was not captured. Please try again.")
                exit()
            else:
                security_rules = get_security_rules(subscription,rg, nsg, bearer_token)
                #pprint(security_rules)
                for each in security_rules:
                    if "sourceAddressPrefix" not in each["properties"].keys():
                        sourceAddressPrefix = each["properties"]["sourceAddressPrefixes"]
                    else:
                        sourceAddressPrefix = [each["properties"]["sourceAddressPrefix"]]
                    if "destinationAddressPrefix" not in each["properties"].keys():
                        destinationAddressPrefix = each["properties"]["destinationAddressPrefixes"]
                    else:
                        destinationAddressPrefix = [each["properties"]["destinationAddressPrefix"]]
                    desinationportranges = []
                    if "destinationPortRange" in each["properties"].keys():
                        if '*' == each["properties"]["destinationPortRange"]:
                            desinationportranges.append(each["properties"]["destinationPortRange"])
                        elif '-' in each["properties"]["destinationPortRange"]:
                            r = each["properties"]["destinationPortRange"].split('-')
                            for b in range(int(r[0]), int(r[1]) + 1):
                                desinationportranges.append(int(b))
                        else:
                            desinationportranges.append(int(each["properties"]["destinationPortRange"]))
                    else:
                        for a in each["properties"]["destinationPortRanges"]:
                            if '-' in a:
                                r = a.split('-')
                                for b in range(int(r[0]), int(r[1]) + 1):
                                    desinationportranges.append(int(b))
                            else:
                                desinationportranges.append(int(a))
                    if (
                        each["properties"]["access"].lower() == "allow" and 
                        each["properties"]["direction"].lower() == "inbound" and 
                        addressprefixvalidator(sourceAddressPrefix) and
                        each["properties"]["protocol"].lower() == "tcp" and
                        (
                            "*" in desinationportranges or
                            any(int(a) in range(0, 53) for a in desinationportranges) or
                            any(int(a) in range(54, 80) for a in desinationportranges) or
                            any(int(a) in range(82, 443) for a in desinationportranges) or
                            any(int(a) in range(444, 1438) for a in desinationportranges) or                            
                            1439 in desinationportranges or
                            any(int(a) in range(1441, 1452) for a in desinationportranges) or
                            any(int(a) in range(1453, 1720) for a in desinationportranges) or
                            any(int(a) in range(1721, 5060) for a in desinationportranges) or
                            any(int(a) in range(5063, 5269) for a in desinationportranges) or
                            any(int(a) in range(5270, 8080) for a in desinationportranges) or
                            any(int(a) in range(8082, 8443) for a in desinationportranges) or
                            any(int(a) in range(8444, 9000) for a in desinationportranges) or
                            any(int(a) in range(9001, 9003) for a in desinationportranges) or
                            any(int(a) in range(9004, 10100) for a in desinationportranges) or
                            any(int(a) in range(10102, 15000) for a in desinationportranges) or 
                            any(int(a) in range(21000, 65200) for a in desinationportranges)
                        )
                    ):
                        non_compliant_rules_inbound.append(
                            {
                                'Name': each['name'],
                                'Direction': each['properties']['direction'],
                                'Source': sourceAddressPrefix,
                                'Protocol': each["properties"]["protocol"],
                                'Port Range': desinationportranges,
                                'Comments': 'Access from the source is not allowed on this protocol and port range.'
                            }
                        )
                    elif(
                        each["properties"]["access"].lower() == "allow" and 
                        each["properties"]["direction"].lower() == "inbound" and 
                        addressprefixvalidator(sourceAddressPrefix) and
                        each["properties"]["protocol"].lower() == "udp" and
                        (
                            "*" in desinationportranges or
                            any(int(a) in range(0, 53) for a in desinationportranges) or
                            any(int(a) in range(54, 500) for a in desinationportranges) or
                            any(int(a) in range(501, 1604) for a in desinationportranges) or
                            any(int(a) in range(1605, 1719) for a in desinationportranges) or
                            any(int(a) in range(1720, 4500) for a in desinationportranges) or
                            any(int(a) in range(4501, 5060) for a in desinationportranges) or
                            any(int(a) in range(5061, 36000) for a in desinationportranges) or
                            any(int(a) in range(60000, 65536) for a in desinationportranges)
                        )
                    ):
                        non_compliant_rules_inbound.append(
                            {
                                'Name': each['name'],
                                'Direction': each['properties']['direction'],
                                'Source': sourceAddressPrefix,
                                'Protocol': each["properties"]["protocol"],
                                'Port Range': desinationportranges,
                                'Comments': 'Access from the source is not allowed on this protocol and port range.'
                            }
                        )     
                    elif(
                        each["properties"]["access"].lower() == "allow" and 
                        each["properties"]["direction"].lower() == "inbound" and 
                        addressprefixvalidator(sourceAddressPrefix) and
                        (
                            each["properties"]["protocol"].lower() == "*" or
                            each["properties"]["protocol"].lower() == "any"
                        )
                    ):
                        non_compliant_rules_inbound.append(
                            {
                                'Name': each['name'],
                                'Direction': each['properties']['direction'],
                                'Source': sourceAddressPrefix,
                                'Protocol': each["properties"]["protocol"],
                                'Port Range': desinationportranges,
                                'Comments': 'Access from the source is not allowed on this protocol and port range.'
                            }
                        )  
                    elif(
                        each["properties"]["access"].lower() == "allow" and 
                        each["properties"]["direction"].lower() == "inbound" and 
                        addressprefixvalidator(sourceAddressPrefix) and
                        each["properties"]["protocol"].lower() == "icmp"
                    ):
                        non_compliant_rules_inbound.append(
                            {
                                'Name': each['name'],
                                'Direction': each['properties']['direction'],
                                'Source': sourceAddressPrefix,
                                'Protocol': each["properties"]["protocol"],
                                'Port Range': desinationportranges,
                                'Comments': 'Access from the source is not allowed on this protocol and port range.'
                            }
                        )
                    elif(
                        each["properties"]["access"].lower() == "allow" and 
                        each["properties"]["direction"].lower() == "outbound" and 
                        addressprefixvalidator(destinationAddressPrefix) and
                        each["properties"]["protocol"].lower() == "tcp" and
                        (
                            "*" in desinationportranges or
                            any(int(a) in range(0, 53) for a in desinationportranges) or
                            any(int(a) in range(54, 80) for a in desinationportranges) or
                            any(int(a) in range(82, 443) for a in desinationportranges) or
                            any(int(a) in range(444, 1720) for a in desinationportranges) or
                            any(int(a) in range(1721, 1886) for a in desinationportranges) or
                            any(int(a) in range(1887, 1935) for a in desinationportranges) or
                            any(int(a) in range(1937, 5060) for a in desinationportranges) or
                            any(int(a) in range(5062, 5269) for a in desinationportranges) or
                            any(int(a) in range(5270, 8080) for a in desinationportranges) or
                            any(int(a) in range(8082, 8443) for a in desinationportranges) or
                            any(int(a) in range(8444, 9001) for a in desinationportranges) or
                            any(int(a) in range(9009, 9092) for a in desinationportranges) or
                            any(int(a) in range(9094, 9997) for a in desinationportranges) or
                            any(int(a) in range(9998, 15000) for a in desinationportranges) or
                            any(int(a) in range(21000, 25000) for a in desinationportranges) or
                            any(int(a) in range(30000, 50000) for a in desinationportranges) or
                            any(int(a) in range(60000, 65536) for a in desinationportranges)
                        )
                    ):
                        non_compliant_rules_outbound.append(
                            {
                                'Name': each['name'],
                                'Direction': each['properties']['direction'],
                                'Destination': destinationAddressPrefix,
                                'Protocol': each["properties"]["protocol"],
                                'Port Range': desinationportranges,
                                'Comments': 'Access from the destination is not allowed on this protocol and port range.'
                            }
                        )
                    elif(
                        each["properties"]["access"].lower() == "allow" and 
                        each["properties"]["direction"].lower() == "outbound" and 
                        addressprefixvalidator(destinationAddressPrefix) and
                        each["properties"]["protocol"].lower() == "udp" and
                        (
                            "*" in desinationportranges or
                            any(int(a) in range(0, 53) for a in desinationportranges) or 
                            any(int(a) in range(54, 123) for a in desinationportranges) or
                            any(int(a) in range(124, 500) for a in desinationportranges) or
                            any(int(a) in range(501, 1604) for a in desinationportranges) or
                            any(int(a) in range(1605, 3478) for a in desinationportranges) or
                            any(int(a) in range(3479, 4500) for a in desinationportranges) or
                            any(int(a) in range(4501, 5060) for a in desinationportranges) or
                            any(int(a) in range(5061, 36000) for a in desinationportranges) or
                            any(int(a) in range(60000, 65536) for a in desinationportranges)
                        )
                    ):
                        non_compliant_rules_outbound.append(
                            {
                                'Name': each['name'],
                                'Direction': each['properties']['direction'],
                                'Destination': destinationAddressPrefix,
                                'Protocol': each["properties"]["protocol"],
                                'Port Range': desinationportranges,
                                'Comments': 'Access from the destination is not allowed on this protocol and port range.'
                            }
                        )
                    elif(
                        each["properties"]["access"].lower() == "allow" and 
                        each["properties"]["direction"].lower() == "outbound" and 
                        addressprefixvalidator(destinationAddressPrefix) and
                        each["properties"]["protocol"].lower() == "icmp"
                    ):
                        non_compliant_rules_outbound.append(
                            {
                                'Name': each['name'],
                                'Direction': each['properties']['direction'],
                                'Destination': destinationAddressPrefix,
                                'Protocol': each["properties"]["protocol"],
                                'Port Range': desinationportranges,
                                'Comments': 'Access from the destination is not allowed on this protocol and port range.'
                            }
                        )
                    elif(
                        each["properties"]["access"].lower() == "allow" and 
                        each["properties"]["direction"].lower() == "outbound" and 
                        addressprefixvalidator(destinationAddressPrefix) and
                        (
                            each["properties"]["protocol"].lower() == "*" or
                            each["properties"]["protocol"].lower() == "any"
                        )
                    ):
                        non_compliant_rules_outbound.append(
                            {
                                'Name': each['name'],
                                'Direction': each['properties']['direction'],
                                'Destination': destinationAddressPrefix,
                                'Protocol': each["properties"]["protocol"],
                                'Port Range': desinationportranges,
                                'Comments': 'Access from the destination is not allowed on this protocol and port range.'
                            }
                        )
                    else:
                        if each['properties']['direction'].lower() == 'inbound':
                            compliant_rules_inbound.append(
                            {
                                'Name': each['name'],
                                'Direction': each['properties']['direction'],
                                'Source': sourceAddressPrefix,
                                'Protocol': each["properties"]["protocol"],
                                'Port Range': desinationportranges,
                                'Comments': 'Secure'
                            }
                        )
                        else:
                            compliant_rules_outbound.append(
                                {
                                    'Name': each['name'],
                                    'Direction': each['properties']['direction'],
                                    'Destination': destinationAddressPrefix,
                                    'Protocol': each["properties"]["protocol"],
                                    'Port Range': desinationportranges,
                                    'Comments': 'Secure'
                                }
                            )
    print(f'\nPlease find the Security Rules status for NSG - {nsg}')
    print("\nNon-Compliant Inbound Rules:")
    if len(non_compliant_rules_inbound) == 0:
        print('No security rules found.')
    else:
        a = 1
        print("{:<5} {:<65} {:<25} {:<15} {:<15} {:<15}".format('POS','Rule Name', 'Source', 'Protocol', 'Port Range', 'Comments'))
        for each in non_compliant_rules_inbound:
            print("{:<5} {:<65} {:<25} {:<15} {:<15} {:<15}".format(a, each['Name'], str(each['Source']), str(each['Protocol']), str(each['Port Range']), each['Comments']))
            a += 1
    print("\nNon-Compliant Outbound Rules:")
    if len(non_compliant_rules_outbound) == 0:
        print('No security rules found.')
    else:
        b = 1
        print("{:<5} {:<65} {:<25} {:<15} {:<15} {:<15}".format('POS','Rule Name', 'Destination', 'Protocol', 'Port Range', 'Comments'))
        for each in non_compliant_rules_outbound:
            print("{:<5} {:<65} {:<25} {:<15} {:<15} {:<15}".format(b, each['Name'], str(each['Destination']), str(each['Protocol']), str(each['Port Range']), each['Comments']))
            b += 1
    print("\nCompliant Inbound Rules:")
    if len(compliant_rules_inbound) == 0:
        print('No security rules found.')
    else:
        c = 1
        print("{:<5} {:<65} {:<25} {:<15} {:<15} {:<15}".format('POS','Rule Name', 'Source', 'Protocol', 'Port Range', 'Comments'))
        for each in compliant_rules_inbound:
            print("{:<5} {:<65} {:<25} {:<15} {:<15} {:<15}".format(c, each['Name'], str(each['Source']), str(each['Protocol']), str(each['Port Range']), each['Comments']))
            c += 1
    print("\nCompliant Outbound Rules:")
    if len(compliant_rules_outbound) == 0:
        print('No security rules found.')
    else:
        d = 1
        print("{:<5} {:<65} {:<25} {:<15} {:<15} {:<15}".format('POS','Rule Name', 'Destination', 'Protocol', 'Port Range', 'Comments'))
        for each in compliant_rules_outbound:
            print("{:<5} {:<65} {:<25} {:<15} {:<15} {:<15}".format(d, each['Name'], str(each['Destination']), str(each['Protocol']), str(each['Port Range']), each['Comments']))
            d += 1
except Exception as e:
    print(e)