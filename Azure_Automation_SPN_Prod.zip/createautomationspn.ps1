try{
    Write-Host "Elevating access for APP ID, Please wait."
    az rest --method post --url "/providers/Microsoft.Authorization/elevateAccess?api-version=2016-07-01"   # elevating access for app ID
    Start-Sleep 30
    Write-Host "Access elevated."
    az account management-group tenant-backfill start
    Start-Sleep 30
    Write-Host "Management group initated. Initiating the Deployment of two automation service principals."
    $cmoTenantId= Read-Host "Enter the CMO Tenant ID"
    $tenantId = (Get-AzContext).Tenant.Id
    write-host "Proceeding with the Azure tenant ID - $tenantId" -ForegroundColor Green
    $confr = Read-Host "Enter y or Y if the Azure tenant ID mentioned above is correct"
      if (($confr -eq "y") -or ($confr -eq "Y")){
        Write-Host "Azure Tenant ID confirmed, proceeding with further steps." -ForegroundColor Green
      }
    else
        {
          Write-Warning "Exiting the script as the Azure tenant ID is not confirmed."
          exit
      }
    $key=Read-Host "Enter your API key for registering it in CMO"
    $header = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"

    $header.Add("Authorization", "API $key")
    $header.Add("Content-Type", "application/json")

    $url1='https://api.cloudplatform.accenture.com/account-enrollment/organization/v1/tenants/'+$cmoTenantId+'/organizations/'+$tenantId
    
    $response = Invoke-RestMethod $url1 -Method 'GET' -Headers $header -StatusCodeVariable "ResponseCode" -SkipHttpErrorCheck

    if (($ResponseCode -eq 200) -and ($response.status -eq "active")){
    Write-host "Validated the given details with response code as - $ResponseCode, proceeding with the creation." -ForegroundColor Green -BackgroundColor DarkMagenta
    }
    elseif(($ResponseCode -eq 200) -and ($response.status -eq "inactive")){
    Write-Warning "The status of the $tenantId under the client $cmoTenantId is inactive, exiting the script."
    exit
    }
    else{
    $response = $response | ConvertTo-Json
    Write-warning "Failed to validate the CMO tenant ID & Azure AD tenant ID response code is - $ResponseCode"
    Write-warning "The response is - "
    write-host $response
    Write-warning "Please validate the entries, exiting the script."
    exit
    }

    $subscriptionid = (Get-AzContext).Subscription.Id
    
    Write-Host "Proceeding with the subscription - $subscriptionid."-ForegroundColor Green -BackgroundColor DarkMagenta
    

    $sp = az ad sp create-for-rbac --name tf-spn --role Owner --scopes "/"| ConvertFrom-Json
    Start-Sleep 40

    $spn_names="CMO-Automation-App-Primary (Do Not Delete)","CMO-Automation-App-Secondary (Do Not Delete)"

    $varstring1 = "-var=target-account={0}" -f $subscriptionId
    $varstring2 = "-var=target-primary={0}" -f $spn_names[0] 
    $varstring3 = "-var=target-secondary={0}" -f $spn_names[1]
    $varstring4 = "-var=target-tenant={0}" -f $tenantId
    $varstring5 = "-var=target-clientId={0}" -f $sp.appId
    $varstring6 = "-var=target-clientSecret={0}" -f $sp.password

    $terraformcommand = @(
    "plan",
    $varstring1,
    $varstring2,
    $varstring3,
    $varstring4,
    $varstring5,
    $varstring6,
    "-out=planbasic.out"
    )
    
    terraform init
    terraform $terraformcommand
    terraform apply -auto-approve planbasic.out


    Write-Host "Deleting the terraform app registration"
    $spn = az ad app list --display-name tf-spn| ConvertFrom-Json
	  az ad app delete --id $spn.appId                                       #Deleting the basic-infra app registration as it has owner access on Root "/"

    foreach($spn_name in $spn_names){
      $clientid= az ad app list --display-name $spn_name | ConvertFrom-Json
      $appId= $clientid.appId
      $enterprise= az ad sp show --id $appId | ConvertFrom-Json
      $objectid= $enterprise.id
      $currentDate = Get-Date
      $endDate = $currentDate.AddMonths(3)
      
      Write-Host "Open the url in new tab and authorize the permissions for Automation SPN - https://login.microsoftonline.com/$tenantId/adminconsent?client_id=$appId"
      Start-Sleep 20
      $conf1 =Read-Host "Enter y or Y once you have authorised the above url "
      if (($conf1 -eq "y") -or ($conf1 -eq "Y")){
        Write-Host "Admin consent granted. Proceeding with further steps."
      }
    else
        {Write-Warning "You have entered incorrect input, if autorization has been completed for the url please press Enter." -WarningAction Inquire
        Write-Host "Proceeding with further steps."}

      $clientsecret=(az ad app credential reset --id $appId --append --display-name "Automation Key" --end-date $endDate --query password --output tsv)     
      $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
      $headers.Add("Authorization", "API $key")
      $headers.Add("Content-Type", "application/json")
      if ($spn_name.Contains("Primary")){
        $scope="aadtenant/primary"
      }
      else{
        $scope="aadtenant/secondary"
      }
    $body =  @"
{
            `"secret`": {
                `"principal`": `"$objectid`",
                `"subscriptionId`": `"NA`",
                `"application`": `"$appId`",
                `"key`": `"$clientsecret`"
            },
            `"accountId`": `"$tenantId`",
            `"tenantId`": `"$cmoTenantId`",
            `"name`": `"tenant-$cmoTenantId-api-keys`",
            `"scope`": `"$scope`",
            `"type`": `"principal`"
}
"@
    $url='https://api.cloudplatform.accenture.com/secret/tenants/'+$cmoTenantId+'/accounts/'+$tenantId+'/secrets'
    $retry = 1
    $timeout= 10
    $response = Invoke-RestMethod $url -Method 'POST' -Headers $headers -Body $body -StatusCodeVariable "ResponseCode" -SkipHttpErrorCheck
    if ($ResponseCode -ne 201){
	    Write-Host "The response code is - $ResponseCode , retrying......"
      while (($retry -le 10) -and ($ResponseCode -ne 201)){
	      Start-Sleep -s $timeout
        $ResponseCode = ""
        Write-Host "Retry count : $retry "
        $response = Invoke-RestMethod $url -Method 'POST' -Headers $headers -Body $body -StatusCodeVariable "ResponseCode" -SkipHttpErrorCheck
        $retry = $retry + 1
    }
  } 
  if (($retry -eq 10) -and ($ResponseCode -ne 201)){
    Write-Warning "Error in pushing the details for $spn_name to CMO DB with response code - $ResponseCode."
  }
  else{
  Write-Host "Successfully completed for $spn_name with response code as - $ResponseCode." -ForegroundColor Green -BackgroundColor DarkMagenta
  }
    }
    Write-Host "Performing cleanup, please wait."
    Clear-AzContext
    Clear-History
    Write-Host "Clean-up performed."
    Write-host "Script completed successfully." -ForegroundColor Green -BackgroundColor DarkMagenta
}
catch{
	Write-Error "Script execution failed with: $($PSItem.Exception.Message)"
	exit
}