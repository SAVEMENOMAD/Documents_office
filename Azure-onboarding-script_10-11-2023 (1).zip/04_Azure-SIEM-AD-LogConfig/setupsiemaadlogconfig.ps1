﻿try{
    $tenantId = Read-Host "Enter the Azure AAD Tenant ID"
	az login -t $tenantId| Out-Null
	# Select subscription scope for deployment
	$subscriptions = Get-AzSubscription
	$subIds = (Get-AzSubscription).Id
	$subsIdName = @{}
	$subscriptions| ForEach-Object{$subsIdName.Add($_.Id,$_. Name)}
	if ($subscriptions.count -gt 1){
	  $subIndex = Read-Host "Select the SIEM subscription(0,1,..). $($subIds.foreach({"`n[$($subIds.IndexOf($PSItem))] $($subsIdName[$PSItem])($PSItem)"}))"
	  if ($subIndex -ge $subscriptions.count){
		  Write-Warning "Selection is out of range, exiting the script."
		  exit
	  }
	  $siemsubscriptionId = $subIds[$subIndex]  
	}
	else {
	  Write-Error "Both Subscription are not available. Please try again."
	  exit
	}
    #Select-AzSubscription -SubscriptionId $subscriptionId| Out-Null
	Write-Host "Enabling Diagnostic Settings..."

    $eventHubNameSpace = "/subscriptions/" + $siemsubscriptionId + "/resourceGroups/CMO-Azure-SIEM/providers/Microsoft.EventHub/namespaces/cmosiem-" + $siemsubscriptionId + "/authorizationRules/RootManageSharedAccessKey"

    $varstring1 = "-state={0}-siem.tfstate" -f $siemsubscriptionId
    $varstring2 = "-var=target-eventhub={0}" -f $eventHubNameSpace

    $terraformcommand = @(
    "plan",
    $varstring1,
    $varstring2,
    "-out=planaad.out"
    )
    terraform init
    terraform $terraformcommand
    terraform apply -auto-approve planaad.out

    Write-Host "Enabling Diagnostic Settings completed." 
    Write-Host "Deleting the temporary files that were created by terraform."
    rm -rf ./planaad.out ./terraform.tfstate 											#removing the temporary files that were created.  
	
}
catch{
	Write-Error "Script execution failed with: $($PSItem.Exception.Message)"
	exit
}