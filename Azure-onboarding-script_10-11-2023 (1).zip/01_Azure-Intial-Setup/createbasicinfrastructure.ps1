try{
    Write-Host "Elevating access for APP ID, Please wait."
    az rest --method post --url "/providers/Microsoft.Authorization/elevateAccess?api-version=2016-07-01"   # elevating access for app ID
    Start-Sleep 30
    Write-Host "Access elevated."
    $cmo_tenant = Read-Host "Enter the CMO Tenant ID"
    $requestorId = Read-Host "Enter the Requestor email id"
    $appid= Read-Host "Enter the APP id that is being used"
    $appid=$appid.split("@")[0]
    $tenantId = Read-Host "Enter the Azure AAD Tenant ID"
    $domain = Read-Host "Enter the Azure AAD Domain"
    $managementgroupId = Read-Host "Do you want to enter custom management group ID ? Press Y to enter the Group id or press any key to proceed with default Tenant Root group"
    if (($managementgroupId -eq "Y") -or ($managementgroupId -eq "y"))
      { $managementgroupId= Read-Host "Enter the management group ID" }
    else {
      Write-Host "Default tenant root group selected, Initating Management groups Please wait."
      az account management-group tenant-backfill start
      Start-Sleep 60
      Write-Host "Management group initated."
      $managementgroupId=$tenantId
    }
    # Select subscription scope for deployment
    $subscriptions = Get-AzSubscription
    $subIds = (Get-AzSubscription).Id
    $subsIdName = @{}
    $subscriptions| ForEach-Object{$subsIdName.Add($_.Id,$_. Name)}
    if ($subscriptions.count -gt 1){	
      $subIndex = Read-Host "Select the main subscription(0,1,..). $($subIds.foreach({"`n[$($subIds.IndexOf($PSItem))] $($subsIdName[$PSItem])($PSItem)"}))"
      if ($subIndex -ge $subscriptions.count){
        Write-Warning "Selection is out of range, exiting the script."
        exit
      }
      $subscriptionId = $subIds[$subIndex]
      $subIndex = Read-Host "Select the SIEM subscription(0,1,..). $($subIds.foreach({"`n[$($subIds.IndexOf($PSItem))] $($subsIdName[$PSItem])($PSItem)"}))"
      if ($subIndex -ge $subscriptions.count){
        Write-Warning "Selection is out of range, exiting the script."
        exit
      }
      $siemsubscriptionId = $subIds[$subIndex]

      Select-AzSubscription -SubscriptionId $siemsubscriptionId| Out-Null
      $sp = az ad sp create-for-rbac --name basic-infra --role Owner --scopes "/"| ConvertFrom-Json  # changes for assigning role on management group   
      Start-Sleep 30

    }
    else {
      Write-Error "Both Subscription are not available. Please try again."
      exit
    }
    
    Write-Host "Setting up the basic infrastructure..."
    $acpspn_name = 'acpapi'
    $chspn_name = 'CloudHealth-' + $cmo_tenant + '-Subscription-App'
    $prismaspn_name = 'Prisma-' + $cmo_tenant + '-Subscription-App'

    $displayname = $requestorId.split("@")[0]
    $display = $requestorId.replace("@", "_")
	  $upn =$display + "#EXT#@" + $domain
    
    $appidobj=az ad user list --display-name $appid --query "[].id" -o tsv

    $varstring1 = "-state={0}-siem.tfstate" -f $subscriptionId
    $varstring2 = "-var=target-account={0}" -f $subscriptionId
    $varstring3 = "-var=target-siemaccount={0}" -f $siemsubscriptionId
    $varstring4 = "-var=target-requestor={0}" -f $requestorId
    $varstring5 = "-var=target-acpspn={0}" -f $acpspn_name 
    $varstring6 = "-var=target-chspn={0}" -f $chspn_name
    $varstring7 = "-var=target-prismaspn={0}" -f $prismaspn_name
    $varstring8 = "-var=target-tenant={0}" -f $tenantId
    $varstring9 = "-var=target-clientId={0}" -f $sp.appId
    $varstring10 = "-var=target-clientSecret={0}" -f $sp.password
    $varstring11 = "-var=target-displayname={0}" -f $displayname
    $varstring12 = "-var=target-upn={0}" -f $upn
    $varstring13 = "-var=target-mggroup={0}" -f $managementgroupId 
    $varstring14 = "-var=target-appid={0}" -f $appidobj 

    $terraformcommand = @(
    "plan",
    $varstring1,
    $varstring2,
    $varstring3,
    $varstring4,
    $varstring5,
    $varstring6,
    $varstring7,
    $varstring8,
    $varstring9,
    $varstring10,
    $varstring11,
    $varstring12,
    $varstring13,
    $varstring14,
    "-out=planbasic.out"
    )
    terraform init
    terraform $terraformcommand
    terraform apply -auto-approve planbasic.out
    
    Write-Host "Deleting the temporary files created by terraform."
    rm -rf planbasic.out terraform.tfstate  #deleting the temporary files.

    Write-Host "Deleting the basic-infra app registration"
    $spn = az ad app list --display-name basic-infra| ConvertFrom-Json
	  az ad app delete --id $spn.appId                                    #Deleting the basic-infra app registration as it has owner access on Root "/"

    Write-Host "Basic infrastructure setup complete. Making some more adjustments..."

    #Register Resource Provider
    az provider register --namespace "microsoft.insights" --subscription $subscriptionId| Out-Null
    az provider register --namespace "Microsoft.Security" --subscription $subscriptionId| Out-Null
    Write-Host "Registered microsoft.insights and Microsoft.Security on $subscriptionId."
    az provider register --namespace "microsoft.insights" --subscription $siemsubscriptionId| Out-Null
    az provider register --namespace "Microsoft.Security" --subscription $siemsubscriptionId| Out-Null
    Write-Host "Registered microsoft.insights and Microsoft.Security on $siemsubscriptionId."

    #Update Security contacts
    az security contact create -n "default" --email 'is.to.vendormonitor@accenture.com' --alert-notifications 'on' --alerts-admins 'on' --subscription $subscriptionId| Out-Null
    Write-Host "Updated Security contact on $subscriptionId"
    az security contact create -n "default" --email 'is.to.vendormonitor@accenture.com' --alert-notifications 'on' --alerts-admins 'on' --subscription $siemsubscriptionId| Out-Null
    Write-Host "Updated Security contact on $siemsubscriptionId"

    # modified here for ARM update to grant admin consent for API permissions for prisma SPN to incoperate AAD onboarding.
    $spn = az ad app list --display-name $prismaspn_name| ConvertFrom-Json
    $prisma= $spn.appId

    Write-Host "Open the url in new tab and authorize the permissions for Prisma Service principal - https://login.microsoftonline.com/$tenantId/adminconsent?client_id=$prisma"
    Start-Sleep 20
    
    $conf1 =Read-Host "Enter y or Y once you have authorised the above url "
    if (($conf1 -eq "y") -or ($conf1 -eq "Y")){
        Write-Host "Changing App id membership to guest."
        get-azureaduser -ObjectId $appidobj |set-azureaduser -usertype Guest
        Write-Host "Completed."}
    else
        {Write-Warning "You have entered incorrect input, if autorization has been completed for the url please press Enter." -WarningAction Inquire
        Write-Host "Changing App id membership to guest."
        get-azureaduser -ObjectId $appidobj |set-azureaduser -usertype Guest
        Write-Host "Completed."}
}
catch{
	Write-Error "Script execution failed with: $($PSItem.Exception.Message)"
	exit
}