﻿try{
    $tenantId = Read-Host "Enter the Azure AAD Tenant ID"
	# Select subscription scope for deployment
	$subscriptions = Get-AzSubscription
	$subIds = (Get-AzSubscription).Id
	$subsIdName = @{}
	$subscriptions| ForEach-Object{$subsIdName.Add($_.Id,$_. Name)}
	if ($subscriptions.count -gt 1){	
	  $subIndex = Read-Host "Select the main subscription(0,1,..). $($subIds.foreach({"`n[$($subIds.IndexOf($PSItem))] $($subsIdName[$PSItem])($PSItem)"}))"
	  if ($subIndex -ge $subscriptions.count){
		  Write-Warning "Selection is out of range, exiting the script."
		  exit
	  }
	  $subscriptionId = $subIds[$subIndex]
	  $subIndex = Read-Host "Select the SIEM subscription(0,1,..). $($subIds.foreach({"`n[$($subIds.IndexOf($PSItem))] $($subsIdName[$PSItem])($PSItem)"}))"
	  if ($subIndex -ge $subscriptions.count){
		  Write-Warning "Selection is out of range, exiting the script."
		  exit
	  }
	  $siemsubscriptionId = $subIds[$subIndex]
	  Select-AzSubscription -SubscriptionId $siemsubscriptionId| Out-Null
	  $sp = az ad sp create-for-rbac --name siem-sp-res --role Owner --scopes "/subscriptions/$subscriptionId" "/subscriptions/$siemsubscriptionId"| ConvertFrom-Json
	  Start-Sleep 30
	}
	else {
	  Write-Error "Both Subscription are not available. Please try again."
	  exit
	}
	$location = Read-Host "Do you want to use a specific geographical location for resource deployment ? Press Y to get a list and select it manually or press any key to proceed with default location East US"
    if (($location -eq "Y") -or ($location -eq "y"))
      { 
		#Hard-code the list of regions to provide a small list (atleast 1 for each geography)
		$possiblelocation = @("eastus","eastus2","westus","westeurope","uksouth","australiaeast","centralindia","canadacentral","uaenorth","brazilsouth","southafricanorth")
		$locationIndex = Read-Host "Select a location(0,1,..) where SIEM resources will be provisioned under SIEM subscription selected $($possiblelocation.foreach({"`n[$($possiblelocation.IndexOf($PSItem))] $PSItem"}))"
		$targetregion = $possiblelocation[$locationIndex]
	  }
    else {
      Write-Host "Proceeding with default location i.e. East us"
      $targetregion='eastus2'
    }

    $varstring1 = "-state={0}-siem.tfstate" -f $siemsubscriptionId
    $varstring2 = "-var=target-siemaccount={0}" -f $siemsubscriptionId
    $varstring3 = "-var=target-region={0}" -f $targetregion
	$varstring4 = "-var=target-tenant={0}" -f $tenantId
	$varstring5 = "-var=target-clientId={0}" -f $sp.appId
	$varstring6 = "-var=target-clientSecret={0}" -f $sp.password

    $terraformcommand = @(
    "plan",
    $varstring1,
    $varstring2,
    $varstring3,
	$varstring4,
	$varstring5,
	$varstring6,
    "-out=planresource.out"
    )
    terraform init
    terraform $terraformcommand
    terraform apply -auto-approve planresource.out

	$spn = az ad app list --display-name siem-sp-res| ConvertFrom-Json
	Write-Host "Deleting the service principal that was created for setup."	
	az ad app delete --id $spn.appId												# Deleting the SIEM spn

	Write-Host "Deleting the temporary files that were created by terraform."
	rm -rf ./planresource.out ./terraform.tfstate 											#removing the temporary files that were created.
}
catch{
	Write-Error "Script execution failed with: $($PSItem.Exception.Message)"
	exit
}