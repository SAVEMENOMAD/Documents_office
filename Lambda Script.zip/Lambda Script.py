'''
Developer ID : manikya.sinha
Reviewer ID : anjanee.kumar
Started Date : 10-04-2024
Completion Date : 15-07-2024
Changes Update Date : 15-08-2024
Change Reason : As part of CMO-8441 I have implemented the emailing function 
Jira No : CMO-6285/CMO-8441
'''
import boto3,pandas,re,json,requests
from datetime import datetime, timedelta
from io import BytesIO

def lambda_handler(event, context):
    
    #Prepare Variables
    table_name = 'fetchclientadminreport'
    bucket_name = 'client-admin-report'
    
    #Boto3 client object for DynamoDB, S3 and SES
    table_client = boto3.client('dynamodb')
    bucket_client = boto3.client('s3')
    email_client = boto3.client('ses', region_name='us-east-1')
    
    #Table scan
    table_response = table_client.scan(TableName=table_name)
    
    #Extract the items from response
    table_items = table_response.get('Items', [])
    
    #Convert it to Dataframe
    table_items = pandas.DataFrame(table_items)
    
    #Filteration
    for i in range(0,len(table_items['roles'])):
      if 'client-admin' in str(table_items['roles'][i]):
        pass
      else:
        table_items = table_items.drop(i)
        
    #Resetting dataframe index
    table_items = table_items.reset_index(drop=True)
    
    #Is it a empty table?
    if table_items.empty:
        print('No client-admin role found in ' + str(table_name))
    
    #Formating the data
    FormattedData = pandas.DataFrame({
            'userId': [''],
            'name': [''],
            'tenantId': [''],
            'scope': ['']
        })
    FormattedData_itr = 0
    
    #Iteration on DB data
    for i in range(0,len(table_items['id'])):
        # Extract email address
        accenture_email_pattern = r"'S': '([^']*)'"
        accenture_email_pattern_match = re.search(accenture_email_pattern,str(table_items['id'][i]))
        if accenture_email_pattern_match:
            FormattedData.loc[FormattedData_itr,'userId'] = accenture_email_pattern_match.group(1)
        else:
            print('StatusCode: 500 | Email address not found in pattern match')
        
        #Extract tenant id
        accenture_tenant_id_pattern = r"'N': '(\d+)'"
        accenture_tenant_id_pattern_match = re.search(accenture_tenant_id_pattern, str(table_items['primaryTenantId'][i]))
        if accenture_tenant_id_pattern_match:
            FormattedData.loc[FormattedData_itr, 'tenantId'] = accenture_tenant_id_pattern_match.group(1)
        else:
            print('StatusCode 500 | Tenant id not found in pattern match')
        
        FormattedData.loc[FormattedData_itr,'name'] = 'client-admin'
        FormattedData.loc[FormattedData_itr,'scope'] = 'tenant'
        FormattedData_itr = FormattedData_itr + 1
      
    #Upload CSV data to S3
    try:
        UTCNow = datetime.utcnow()
        ISToffset = timedelta(hours=5, minutes=30)
        ISToffset = UTCNow + ISToffset
        #CurrentDate = ISToffset.strftime('%Y-%m-%d_%H-%M-%S')
        #CSVfilename = f'RoleData_{CurrentDate}.csv'
        CSVfilename = f'RoleData.csv'
        CSVbuffer = BytesIO()
        FormattedData.to_csv(CSVbuffer, index=False)
        CSVbuffer.seek(0)
        bucket_client.put_object(
            Bucket=bucket_name,
            Key=CSVfilename,
            Body=CSVbuffer.getvalue(),
            ContentType='text/csv'
        )
        print('StatusCode: 200 | CSV file uploaded to S3 successfully')
    except Exception as s3_error:
        print("Error: 500 while uploading CSV file in S3")
        print(s3_error)
    
    try:
        #Generating pre-signed url
        s3_object_key_expiration = 172800  # 2 days
        s3_presigned_url = bucket_client.generate_presigned_url(
        'get_object',
        Params={'Bucket': bucket_name, 'Key': CSVfilename},
        ExpiresIn=s3_object_key_expiration
        )
        print("Pre-Signed URL Generated")
        #Email detail
        email_to = 'NA'
        email_subject = 'CMO Client Admin Report'
        email_body =f'''
        <html>
        <body>
        Please find the latest Client Admin List report <a href="{s3_presigned_url}">here</a>.
        </body>
        </html>
        '''
        #Sending email
        CMO_Email_API = 'https://api.cloudplatform.accenture.com/action/email/send'
        headers = {
            'Authorization': f'API qDyB_HEsa0gytvGw',
            'Content-Type': 'application/json'
            }
        with open("config.json", 'r') as jsonfile:   
            email_to = json.load(jsonfile)
            
        CMO_Email_API_Data = {
            'subject': email_subject,
            'to': [email_to['email_list']],
            'body': email_body,
            'title': email_subject
            }
        CMO_Email_API_Response = requests.post(CMO_Email_API, headers=headers, data=json.dumps(CMO_Email_API_Data))
        if CMO_Email_API_Response.status_code != 201:
                    print('Error: '+str(CMO_Email_API_Response.status_code)+" "+str(CMO_Email_API_Response.text))
        else:
                    print('Email send to '+str(email_to))
    except Exception as email_error:
        print('Unable to send email')
        print(email_error)
